<!-- Footer section Starts -->
<div class="footer">
        <div class="wrapper">
            <p class="text-center">2022 All rights reserved, Solihull Canteen. Developed By - <a href="https://github.com/SierraRomeo187/SierraRomeo187"> Sanaur Rahman</a></p>
        </div>
    </div>
    <!-- Footer Section Ends -->
</body>
</html>